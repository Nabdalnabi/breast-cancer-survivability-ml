"""Synthetic data creation and input validation.

The generator supports software demonstrations only. It does not emulate the
joint distribution of the governed clinical cohort.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.datasets import make_classification

TARGET = "five_year_survival"

FEATURE_NAMES = [
    "age_at_diagnosis",
    "tumor_size_mm",
    "tumor_grade",
    "node_positive",
    "er_positive",
    "pr_positive",
    "her2_positive",
    "menopausal_status",
    "breast_density",
    "tumor_quadrant_upper_outer",
    "tumor_quadrant_upper_inner",
    "tumor_quadrant_lower_outer",
    "tumor_quadrant_lower_inner",
    "tumor_quadrant_other",
    "laterality_left",
    "histology_idc",
    "chemotherapy_received",
    "neoadjuvant_therapy",
    "lumpectomy",
    "mastectomy",
]


def make_synthetic_cohort(n_samples: int = 401, random_state: int = 42) -> pd.DataFrame:
    """Return a deterministic, identifier-free demonstration dataset."""
    features, target = make_classification(
        n_samples=n_samples,
        n_features=len(FEATURE_NAMES),
        n_informative=11,
        n_redundant=3,
        n_clusters_per_class=2,
        weights=[0.24, 0.76],
        class_sep=1.15,
        flip_y=0.03,
        random_state=random_state,
    )
    frame = pd.DataFrame(features, columns=FEATURE_NAMES)

    rng = np.random.default_rng(random_state)
    frame["age_at_diagnosis"] = np.clip(58 + 11 * frame["age_at_diagnosis"], 25, 90).round(1)
    frame["tumor_size_mm"] = np.clip(28 + 14 * frame["tumor_size_mm"], 2, 100).round(1)
    frame["tumor_grade"] = pd.qcut(frame["tumor_grade"], 3, labels=[1, 2, 3]).astype(int)
    frame["breast_density"] = pd.qcut(frame["breast_density"], 4, labels=[1, 2, 3, 4]).astype(int)

    binary_columns = [name for name in FEATURE_NAMES if name not in {
        "age_at_diagnosis", "tumor_size_mm", "tumor_grade", "breast_density"
    }]
    for column in binary_columns:
        threshold = rng.normal(0, 0.15)
        frame[column] = (frame[column] > threshold).astype(int)

    frame[TARGET] = target.astype(int)
    validate_modeling_frame(frame)
    return frame


def validate_modeling_frame(frame: pd.DataFrame) -> None:
    """Fail early when a modeling frame violates the public schema."""
    expected = set(FEATURE_NAMES + [TARGET])
    missing = expected.difference(frame.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    if frame[list(expected)].isna().any().any():
        raise ValueError("Modeling data contain missing values; define an explicit imputation policy.")
    if frame[TARGET].nunique() != 2:
        raise ValueError("The target must contain exactly two classes.")
