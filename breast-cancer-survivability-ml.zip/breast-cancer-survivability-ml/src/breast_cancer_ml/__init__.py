"""Privacy-preserving breast cancer survivability modeling demo."""

__version__ = "0.1.0"
