"""Camera-ready aggregate evaluation plots."""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
from sklearn.base import BaseEstimator
from sklearn.metrics import PrecisionRecallDisplay, RocCurveDisplay

COLORS = ["#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9"]


def save_curve_figures(
    fitted_models: Mapping[str, BaseEstimator],
    x_test: pd.DataFrame,
    y_test: pd.Series,
    output_dir: str | Path,
) -> None:
    """Save publication-quality ROC and precision-recall comparisons."""
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    for curve_name, display_class, axis_label in [
        ("roc_curves", RocCurveDisplay, "ROC curve"),
        ("precision_recall_curves", PrecisionRecallDisplay, "Precision-recall curve"),
    ]:
        figure, axis = plt.subplots(figsize=(7.2, 5.4), constrained_layout=True)
        for color, (name, model) in zip(COLORS, fitted_models.items()):
            display_class.from_estimator(model, x_test, y_test, name=name.replace("_", " ").title(), ax=axis, color=color)
        axis.set_title(f"{axis_label}, synthetic demonstration cohort", fontweight="bold")
        axis.grid(alpha=0.22, linewidth=0.7)
        axis.legend(frameon=False, fontsize=8)
        figure.savefig(output_path / f"{curve_name}.png", dpi=300, bbox_inches="tight")
        plt.close(figure)
