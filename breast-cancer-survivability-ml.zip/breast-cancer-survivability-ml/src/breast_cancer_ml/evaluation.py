"""Model evaluation with a locked holdout set."""

from __future__ import annotations

from collections.abc import Mapping

import pandas as pd
from sklearn.base import BaseEstimator
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold, cross_validate

SCORING = {"roc_auc": "roc_auc", "average_precision": "average_precision", "f1": "f1"}


def evaluate_models(
    models: Mapping[str, BaseEstimator],
    x_train: pd.DataFrame,
    y_train: pd.Series,
    x_test: pd.DataFrame,
    y_test: pd.Series,
    random_state: int = 42,
) -> tuple[pd.DataFrame, dict[str, BaseEstimator]]:
    """Fit each pipeline and return holdout plus training-CV metrics."""
    cross_validator = StratifiedKFold(n_splits=5, shuffle=True, random_state=random_state)
    records: list[dict[str, float | str]] = []
    fitted_models: dict[str, BaseEstimator] = {}

    for name, pipeline in models.items():
        cv = cross_validate(
            pipeline,
            x_train,
            y_train,
            scoring=SCORING,
            cv=cross_validator,
            n_jobs=1,
        )
        pipeline.fit(x_train, y_train)
        prediction = pipeline.predict(x_test)
        probability = pipeline.predict_proba(x_test)[:, 1]

        records.append(
            {
                "model": name,
                "precision": precision_score(y_test, prediction, zero_division=0),
                "recall": recall_score(y_test, prediction, zero_division=0),
                "f1": f1_score(y_test, prediction, zero_division=0),
                "accuracy": accuracy_score(y_test, prediction),
                "roc_auc": roc_auc_score(y_test, probability),
                "average_precision": average_precision_score(y_test, probability),
                "cv_roc_auc_mean": cv["test_roc_auc"].mean(),
                "cv_roc_auc_std": cv["test_roc_auc"].std(),
            }
        )
        fitted_models[name] = pipeline

    metrics = pd.DataFrame.from_records(records).sort_values("roc_auc", ascending=False)
    return metrics.reset_index(drop=True), fitted_models
