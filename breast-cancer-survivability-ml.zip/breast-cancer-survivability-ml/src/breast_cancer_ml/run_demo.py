"""Command-line entry point for the privacy-safe demonstration."""

from __future__ import annotations

import argparse
from pathlib import Path

from sklearn.model_selection import train_test_split

from .data import FEATURE_NAMES, TARGET, make_synthetic_cohort
from .evaluation import evaluate_models
from .modeling import build_models
from .plotting import save_curve_figures


def run(output_dir: str | Path, random_state: int = 42):
    """Execute the complete synthetic workflow and save aggregate artifacts."""
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    cohort = make_synthetic_cohort(random_state=random_state)
    x_train, x_test, y_train, y_test = train_test_split(
        cohort[FEATURE_NAMES],
        cohort[TARGET],
        test_size=0.20,
        stratify=cohort[TARGET],
        random_state=random_state,
    )
    metrics, fitted_models = evaluate_models(
        build_models(random_state), x_train, y_train, x_test, y_test, random_state
    )
    metrics.to_csv(output_path / "synthetic_demo_metrics.csv", index=False)
    save_curve_figures(fitted_models, x_test, y_test, output_path)
    return metrics


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", default="artifacts")
    parser.add_argument("--seed", type=int, default=42)
    arguments = parser.parse_args()
    print(run(arguments.output_dir, arguments.seed).round(3).to_string(index=False))


if __name__ == "__main__":
    main()
