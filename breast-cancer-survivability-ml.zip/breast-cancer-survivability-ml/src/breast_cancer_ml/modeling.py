"""Leakage-safe model construction."""

from __future__ import annotations

from collections import OrderedDict

from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline
from sklearn.ensemble import AdaBoostClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from xgboost import XGBClassifier


def build_models(random_state: int = 42) -> OrderedDict[str, Pipeline]:
    """Create comparable pipelines with resampling restricted to training folds."""
    smote = SMOTE(random_state=random_state)
    estimators = OrderedDict(
        xgboost=XGBClassifier(
            n_estimators=200,
            max_depth=3,
            learning_rate=0.05,
            subsample=0.9,
            colsample_bytree=0.9,
            eval_metric="logloss",
            random_state=random_state,
            n_jobs=1,
        ),
        random_forest=RandomForestClassifier(
            n_estimators=300,
            min_samples_leaf=2,
            class_weight="balanced_subsample",
            random_state=random_state,
            n_jobs=1,
        ),
        decision_tree=DecisionTreeClassifier(
            max_depth=5,
            class_weight="balanced",
            random_state=random_state,
        ),
        logistic_regression=LogisticRegression(
            C=1.0,
            class_weight="balanced",
            max_iter=2_000,
            random_state=random_state,
        ),
        support_vector_classifier=SVC(
            C=1.0,
            kernel="linear",
            probability=True,
            class_weight="balanced",
            random_state=random_state,
        ),
        adaboost=AdaBoostClassifier(
            n_estimators=200,
            learning_rate=0.05,
            random_state=random_state,
        ),
    )

    models: OrderedDict[str, Pipeline] = OrderedDict()
    for name, estimator in estimators.items():
        steps = [("resample", smote)]
        if name in {"logistic_regression", "support_vector_classifier"}:
            steps.append(("scale", StandardScaler()))
        steps.append(("model", estimator))
        models[name] = Pipeline(steps)
    return models
