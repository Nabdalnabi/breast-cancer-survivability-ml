# Data access

No clinical data are distributed with this repository.

The public demo generates synthetic observations in memory. Researchers with authorization to use the governed dataset should store it outside Git, confirm the expected schema locally, and never commit extracts, identifiers, dates, record-level predictions, or serialized models trained on restricted data.
